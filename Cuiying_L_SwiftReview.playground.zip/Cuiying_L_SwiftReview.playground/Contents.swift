/*: - Copyright :  Bulldog Ventures Inc  ©  2020 */
import UIKit

/*:

- Variables

Create a variable called name and initialize it to the name of your favorite actor, singer, or sports celebrity */
var name = "Taylor Swift"
/*:
- Displaying on the screen

Display the contents of name on the screen

 Change the value of name to your name*/
print(name)
//new line between sections
print("")

name = "Cuiying"
/*:
- Constants
 
Display the contents of name

Create a constant (let instead of var) called language and initialize it to "Swift"

Display the contents of the language constant on screen

Create 3 different constants and initialize them to hold integers of your choice. Name the constants a, b, and c

Create 3 constants that are doubles (they have decimal points) Initialize them with values of your choice. Name the constants d, e, and f*/
print(name)

let language = "Swift"

print(language)
//new line between sections
print("")

let a: Double = 2
let b: Double = 3
let c: Double = 4

let d: Double = 1.2
let e: Double = 2.3
let f: Double = 3.4
/*:
- Operators

Create an assortment of statements using the constants that you created that will perform the following actions - then display the equation and the result on the screen.*/
/*
 addition: a + b + c + d
 subtraction: b - d
 division: c / e
 multiplication: e * f
 */
/*:
- Add two constants
 
-                print("a + b = " ) + (a + b)

Addition sample with at least 4 constants

Subtraction sample

Division sample

Multiplication sample*/
print("a + b + c + d = \(a + b + c + d)")
print("b - d = \(b - d)")
print("c / e = \(c / e)")
print("e * f = \(e * f)")

//new line between sections
print("")
/*:
- If Statements
 
Use the following constants to solve the problems :*/
 
let temperature = 90
let raining = true
let time = "Morning"

/*: Write a statement that tells someone to wear shorts if it is over 80 degrees, and jeans if it is less than 80 degrees. Check with the temperature constant

Check the raining constant and tell the user if they need an umbrella or not

Check the time constant and if it is morning tell the user to go to school, if it is afternoon tell the user to go home, and if it is night tell the user to go to bed*/
if temperature > 80 {
    print("It's really hot, wear shorts.")
} else if temperature < 80 {
    print("It's kind of cold, wear jeans.")
}

if raining == true {
    print("It's raining, you need an umbrella.")
} else {
    print("It's not raining, you don't need an umbrella.")
}

if time == "Morning" {
    print("It's morning, you need to go to school.")
} else if time == "Afternoon" {
    print("It's afternoon, you need to go home.")
} else if time == "Night" {
    print("It's night, you need to go to bed.")
}

//new line between sections
print("")
/*:
- Loops

Using a for loop print the numbers from 1 to 10 on screen

Using  a while loop print the numbers from 10 to 1 on screen*/
for value in 1...10 {
    print(value)
}

//new line between sections
print("")

var number = 10

while number > 0 {
    print(number)
    number = number - 1
}

//new line between sections
print("")
/*:
- Collections

Create an array that holds five strings

Create a tuple that holds two strings

Using a loop, step through one of the collections you created and print all of the items to the screen*/
var array: [String] = ["One", "Two", "Three", "Four", "Five"]
var tuple = (left: "Right", right: "Left")

for items in array {
    print(items)
}

//new line between sections
print("")
/*:
- Functions

Create a function that takes two doubles, multiplies them, and returns the result.

Call the function, save the result in the variable "answer". Pass it two of the constants you  creataed (a, b, c, d, e, or f)*/
func multiplcation(num1: Double, num2: Double) -> Double {
    return num1 * num2
}

var answer = multiplcation(num1: d, num2: f)
/*:
- Closures

Create a closure that subtracts one number from another and prints the results, use the closure. You may pass it constants or numbers*/
var subtraction = { (num1: Double, num2: Double) -> Double in
    return num1 - num2
}

var difference = subtraction(a, f)
print(difference)

//new line between sections
print("")
/*:
- Enums
 
Create an enum that holds the first name of everyone in your group

Create a switch statement based on the enum that will display the birthday of the
selected person

Test it by using your own name*/
enum Names {
    case Aidan
    case Yasmine
    case Alex
    case Jonathan
    case Michon
    case Cuiying
}

var birthday = Names.Cuiying
switch birthday {
case .Aidan:
    print("June 29")
case .Yasmine:
    print("September 19")
case .Alex:
    print("July 2")
case .Jonathan:
    print("March 13")
case .Michon:
    print("December 17")
case .Cuiying:
    print("November 15")
}

print()
/*:
- Structure
 
Create a structure called Name that holds a first, middle, and last name and prints them on screen in one line with spaces between them

Create an instance of the Name structure, pass it your name, and use the instance you created to print your  name to the screen*/
struct Name {
    var who = { (first: String, middle: String, last: String) -> String in
        return "\(first) \(middle) \(last)"
    }
}

var me = Name()
print(me.who("Cuiying", "", "Lin"))

//new line between sections
print("")
/*:
- Class
 
Create a class called Coffee that accepts size, caffineated,  cream,  and sugar then prints the order on screen

Create an instance of the class

Use the instance of the class and call the function*/
class Coffee {
    func order(size: String, caffeinated: String, cream: String, sugar: String) -> String {
        let orderOnScreen = "\(size), \(caffeinated) coffee with \(cream) and \(sugar)."
        return orderOnScreen
    }
}

var customerOrder = Coffee()

print(customerOrder.order(size: "large", caffeinated: "decaf", cream: "no cream", sugar: "no sugar"))
